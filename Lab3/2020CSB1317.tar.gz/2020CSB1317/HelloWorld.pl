#!/usr/local/bin/perl
print "Hello, world!\n";
