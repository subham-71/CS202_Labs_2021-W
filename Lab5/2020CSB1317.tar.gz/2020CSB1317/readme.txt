To run the programs : perl FileName.pl

In Task4.pl -> my program will be able to detect single words or pair of words in double quotes only.

In RegexTime.pl ->
Apart from given guidelines,
my program will consider it true if the hours and minutes place is single digit and is written like this (9 or 09)

Accepted formats : 
12.09 am
12.9 am
12.43 pm
8.09 am
08.09 pm
08.44 pm



