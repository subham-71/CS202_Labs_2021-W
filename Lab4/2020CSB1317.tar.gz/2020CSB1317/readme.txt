To run the program : perl Hangman.pl


The word to be chosen is randomly chosen from the list of words given in the assignment.
The hangman has 7 body parts. So you  can wrongly guess for at max 7 times.

The program displays the current status of the letters you have guessed after every guess.

It also gives you the status of the hangman in both graphic and text format (about how many body parts are left).
