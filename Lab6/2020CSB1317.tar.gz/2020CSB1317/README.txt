To run the files :
perl Truck.pl
perl Gene.pl
perl Token.pl

Please give input to the programs from the terminal and press "enter" to view the output.

Assumptions :

Truck.pl
The phrase matching is case insensitive
Price is accepted in the following formats : 
    $5000
    $ 5000
    $.14
Special characters between words of the required phrase in the input text are also allowed.


Token.pl
Delimiters can be a character or a set of characters


