To compile the java program in linux terminal : javac TicTacToe.java
To execute : java TicTacToe

Enter 1 for two-player game
Enter 2 for playing aganinst computer

Board position numbers :
| 1 | 2 | 3 |
| 4 | 5 | 6 |
| 7 | 8 | 9 |

Computer strategy : 
If there are two 'O's adjacent to each other in any direction, computer tries to complete the streak and win it.
Also,computer tries to block the next adjacent cell if it finds two adjacent 'X' symbols in any valid direction.

Please try to follow the instructions that are being displayed in the terminal while giving inputs.

